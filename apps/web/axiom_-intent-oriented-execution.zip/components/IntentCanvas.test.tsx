
/**
 * @axiom-test-suite IntentCanvas.v2
 * Logic Probes: Undo/Redo, Async Orchestration, Tier Validation
 */

import React from 'react';
import { render, screen, fireEvent, act } from '@testing-library/react';
import { vi, describe, it, expect, beforeEach } from 'vitest';
import IntentCanvas from './IntentCanvas';
import * as geminiService from '../services/geminiService';
import { IVCUStatus, ModelTier } from '../types';

// Mock high-latency services
vi.mock('../services/geminiService', () => ({
  parseIntent: vi.fn(),
  generateVerifiedCode: vi.fn(),
}));

describe('IntentCanvas Component Strategy', () => {
  const mockOnGenerated = vi.fn();
  const mockAddLog = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers();
  });

  it('PROBE: Undo/Redo Semantic Stack Integrity', async () => {
    render(<IntentCanvas onGenerated={mockOnGenerated} addLog={mockAddLog} />);
    const textarea = screen.getByPlaceholderText(/Describe your system intent/i);

    // Stage 1: Initial Intent
    fireEvent.change(textarea, { target: { value: 'State Alpha' } });
    act(() => { vi.advanceTimersByTime(1000); });

    // Stage 2: Modified Intent
    fireEvent.change(textarea, { target: { value: 'State Beta' } });
    act(() => { vi.advanceTimersByTime(1000); });

    // Probe Undo
    const undoBtn = screen.getByLabelText(/Undo semantic change/i);
    fireEvent.click(undoBtn);
    expect(textarea.value).toBe('State Alpha');

    // Probe Redo
    const redoBtn = screen.getByLabelText(/Redo semantic change/i);
    fireEvent.click(redoBtn);
    expect(textarea.value).toBe('State Beta');
  });

  it('PROBE: Model Tier Cost Assignment', async () => {
    render(<IntentCanvas onGenerated={mockOnGenerated} addLog={mockAddLog} />);
    
    // Select Frontier Tier
    const frontierBtn = screen.getByText('Frontier');
    fireEvent.click(frontierBtn);

    // Mock successful synthesis
    (geminiService.parseIntent as any).mockResolvedValue({ confidence: 1, constraints: [] });
    (geminiService.generateVerifiedCode as any).mockResolvedValue('// Code');

    const submitBtn = screen.getByText('EXECUTE INTENT');
    fireEvent.click(submitBtn);

    await act(async () => {
      vi.runAllTimers();
    });

    // Check last emission for correct cost ($0.125 for Frontier)
    const lastCall = mockOnGenerated.mock.calls[mockOnGenerated.mock.calls.length - 1][0];
    expect(lastCall.cost).toBe(0.125);
  });

  it('PROBE: Async Orchestration Pipeline', async () => {
    render(<IntentCanvas onGenerated={mockOnGenerated} addLog={mockAddLog} />);
    const textarea = screen.getByPlaceholderText(/Describe your system intent/i);
    fireEvent.change(textarea, { target: { value: 'Secure Auth' } });

    // Setup partial success
    (geminiService.parseIntent as any).mockResolvedValue({ 
      confidence: 0.9, 
      constraints: ['Use Argon2'] 
    });
    (geminiService.generateVerifiedCode as any).mockResolvedValue('const auth = () => {}');

    const submitBtn = screen.getByText('EXECUTE INTENT');
    fireEvent.click(submitBtn);

    // Verify initial "Generating" signal
    expect(mockOnGenerated).toHaveBeenCalledWith(expect.objectContaining({
      status: IVCUStatus.Generating
    }));

    await act(async () => {
      vi.runAllTimers();
    });

    // Verify final "Verified" signal
    expect(mockOnGenerated).toHaveBeenLastCalledWith(expect.objectContaining({
      status: IVCUStatus.Verified,
      code: 'const auth = () => {}'
    }));
    
    expect(mockAddLog).toHaveBeenCalledWith(expect.stringContaining('Consensus achieved'));
  });
});
