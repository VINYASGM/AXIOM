
import { GoogleGenAI, Type } from "@google/genai";
import { ModelTier } from "../types";

// Always initialize with verified API key from process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

const getModelForTier = (tier: ModelTier) => {
  switch (tier) {
    case ModelTier.Local: return 'gemini-flash-lite-latest';
    case ModelTier.Fast: return 'gemini-3-flash-preview';
    case ModelTier.Capable: return 'gemini-3-pro-preview';
    case ModelTier.Frontier: return 'gemini-3-pro-preview'; // Research grade mapping
    default: return 'gemini-3-flash-preview';
  }
};

export const parseIntent = async (prompt: string, complexity: number = 5, tier: ModelTier = ModelTier.Fast) => {
  const modelName = getModelForTier(tier);
  const response = await ai.models.generateContent({
    model: modelName,
    contents: `Analyze the following developer intent and extract architectural constraints, logic flow, and required technologies. 
    Target Synthesis Complexity: ${complexity}/10. 
    (1-3: Simple script, 4-6: Modular library, 7-10: Distributed Enterprise System).
    Input: "${prompt}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          interpretation: { type: Type.STRING },
          constraints: { type: Type.ARRAY, items: { type: Type.STRING } },
          entities: { type: Type.ARRAY, items: { type: Type.STRING } },
          confidence: { type: Type.NUMBER }
        },
        required: ["interpretation", "constraints", "entities", "confidence"]
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

export const generateVerifiedCode = async (intent: string, constraints: string[], complexity: number = 5, tier: ModelTier = ModelTier.Fast) => {
  const modelName = getModelForTier(tier);
  
  // Sophisticated budget allocation: Pro models get reasoning capacity
  let thinkingBudget = 0;
  if (modelName === 'gemini-3-pro-preview') {
    thinkingBudget = 32768; // Max budget for deep synthesis
  }

  const response = await ai.models.generateContent({
    model: modelName,
    contents: `Based on this intent: "${intent}" and these constraints: [${constraints.join(', ')}], generate high-quality production code. 
    The target complexity level is ${complexity}/10. 
    Include internal logic verification blocks. Ensure maximum performance and safety.`,
    config: {
      thinkingConfig: thinkingBudget > 0 ? { thinkingBudget } : undefined
    }
  });
  return response.text;
};

export const generateIntentVisual = async (intent: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ 
        text: `Technical architectural blueprint schematic of a software system described as: "${intent}". 
        Visual: Glowing obsidian console, technical blueprint lines, data flow vectors, minimalist scientific instrumentation style. 
        Cinematic lighting, high-tech holographic overlays, 8k resolution.` 
      }]
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9"
      }
    }
  });

  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  if (part?.inlineData) {
    return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
  }
  return null;
};
